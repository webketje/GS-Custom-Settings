<?php 
	$tab = 'some_setting';
	$settings = array(
		array('lookup'=>'my_first_setting',  'tab'=>'social', 'type'=>'text', 'label'=>'My first Setting', 'value' => 'Lots of love'),
		array('lookup'=>'my_second_setting',  'tab'=>'social', 'type'=>'checkbox', 'label'=>'GSDEBUG on?', 'value'=> GSDEBUG),
		array('lookup'=>'my_third_setting',  'tab'=>'social', 'type'=>'radio', 'label'=>'Some options', 'options' => array('Option 1', 'Option 2', 'Option 3'), 'value'=> 2),
		array('lookup'=>'my_fourth_setting',  'tab'=>'social', 'type'=>'text', 'label'=>'My second Setting')
	);
?>