<?php 
	$plugin = array('lookup'=>'GSCONFIG', 'label'=> 'GetSimple Config');
	$settings = array(
		array('lookup'=>'gs_login_salt',
			'label'=>'Extra salt to secure your password with',
			'type'=>'text',
			'value'=>'',
			'constant'=>'GSLOGINSALT'),	
		array('lookup'=>'gs_custom_salt', 
			'label'=>'Turn off auto-generation of SALT and use a custom value:',
			'type'=>'text',
			'value'=> '',
			'constant'=>'GSUSECUSTOMSALT'),		
		array('lookup'=>'gs_image_width',
			'label'=>'Default thumbnail width of uploaded image',
			'type'=>'text',
			'value'=> '200',
			'constant'=> 'GSIMAGEWIDTH'),		
		array('lookup'=>'gs_admin',
			'label'=>'Administrative panel folder name:',
			'type'=>'text',
			'value'=>'admin', 
			'constant'=> 'GSADMIN'),	
		array('lookup'=>'gs_debug',
			'label'=>'Turn on debug mode',
			'type'=>'checkbox',
			'value'=> FALSE, 
			'constant'=> 'GSDEBUG'),		
		array('lookup'=>'gs_do_not_ping',
			'label'=>'Ping search engines upon sitemap generation?',
			'type'=>'checkbox',
			'value'=> TRUE,
			'constant'=> 'GSDONOTPING'),		
		array('lookup'=>'gs_no_csrf',
			'label'=>'Turn off CSRF protection?',
			'descr'=>'Check this if you keep receiving the error message "CSRF error detected..."',
			'type'=>'checkbox',
			'value'=> FALSE,
			'constant'=>'GSNOCSRF'),		
		array('lookup'=>'gs_chmod',
			'label'=>'Override CHMOD?',
			'type'=>'text',
			'value'=> '',
			'constant'=>'GSCHMOD'),
		array('lookup'=>'gs_canonical',
			'label'=>'Enable Canonical Redirects?',
			'type'=>'checkbox',
			'value'=> FALSE,
			'constant'=>'GSCANONICAL'),
		array('lookup'=>'gs_no_uploadify',
			'label'=>'Use Uploadify to upload files?',
			'type'=>'checkbox',
			'value'=> TRUE,
			'constant'=>'GSNOUPLOADIFY'),
		array('lookup'=>'gs_editor_height',
			'label'=>'WYSIWYG editor height',
			'type'=>'text',
			'value'=> 500,
			'constant'=>'GSEDITORHEIGHT'),
		array('lookup'=>'gs_editor_toolbar',
			'label'=>'WYSIWYG editor toolbar:',
			'type'=>'radio',
			'options'=> array('basic','advanced'),
			'value'=> 'basic',
			'constant'=>'GSEDITORTOOL'),
		array('lookup'=>'gs_editor_lang',
			'label'=>'WYSIWYG editor language:',
			'type'=>'text',
			'value'=> 'en',
			'constant'=>'GSEDITORLANG'),
		array('lookup'=>'gs_editor_options',
			'label'=>'WYSIWYG editor options',
			'type'=>'text',
			'value'=> '',
			'constant'=> 'GSEDITOROPTIONS'),
		array('lookup'=>'gs_from_email',
			'label'=>'Set email from address:',
			'type'=>'text',
			'value'=> 'noreply@get-simple.info',
			'constant'=> 'GSFROMEMAIL'),
		array('lookup'=>'gs_ext_api',
			'label'=>'Enable the External API to be shown on settings page ',
			'type'=>'checkbox',
			'value'=> FALSE,
			'constant'=>'GSEXTAPI'),
		array('lookup'=>'php_locale',
			'label'=>'Define default timezone of server (PHP)',
			'descr'=>'See http://php.net/manual/en/function.setlocale.php for details.',
			'type'=>'text',
			'value'=> 'en_US',
			'constant'=>'set_locale'),
		array('lookup'=>'define_server_time',
			'label'=>'Define default timezone of server (PHP)',
			'descr'=>'Valid timezones can be found here http://www.php.net/manual/en/timezones.php.',
			'type'=>'text',
			'value'=> '',
			'constant'=>'GSTIMEZONE'),
		array('lookup'=>'gs_no_cdn',
			'label'=>'Disable loading of external CDN versions of scripts (jQuery/jQueryUI)',
			'type'=>'checkbox',
			'value'=> FALSE,
			'constant'=>'GSNOCDN'),
		array('lookup'=>'gs_no_highlight',
			'label'=>'Disable Codemirror theme editor',
			'type'=>'checkbox',
			'value'=> FALSE,
			'constant'=>'GSNOHIGHLIGHT'),
		array('lookup'=>'suppress_php_errors',
			'label'=>'Suppress PHP errors',
			'descr'=>'Forces suppression of php errors when GSDEBUG is false, despite php ini settings',
			'type'=>'text',
			'value'=> FALSE,
			'constant'=>'GSSUPPRESSERRORS'),
		array('lookup'=>'gs_no_apache_check',
			'label'=>'Disable check for Apache web server',
			'type'=>'checkbox',
			'value'=> FALSE,
			'constant'=>'GSNOAPACHECHECK'),
		array('lookup'=>'gs_no_ver_check',
			'label'=>'Disable header version check',
			'type'=>'checkbox',
			'value'=> FALSE,
			'constant'=>'GSNOVERCHECK'),
		array('lookup'=>'gs_no_sitemap',
			'label'=>'Disable Sitemap generation and menu items',
			'type'=>'checkbox',
			'value'=> FALSE,
			'constant'=>'GSNOSITEMAP'),
		array('lookup'=>'auto_meta_descr',
			'label'=>'Enable auto meta descriptions from content excerpts when empty',
			'type'=>'checkbox',
			'value'=> FALSE,
			'constant'=>'GSAUTOMETAD'),
		array('lookup'=>'gs_merge_lang',
			'label'=>'Set default language for missing lang token merge',
			'type'=>'text',
			'value'=> 'en_US',
			'constant'=>'GSMERGELANG')
	);
	function updateConfigSetting($settingName, $value) {
	
		$cfgSettingUpdated = 'define(\'' . $settingName . ', ' . $value . '\')';
		$cfgSettingRegex = '#define(\'' . $settingName . '.*, \')#';
		$cfgComment = '# ' . $cfgSetting;
		
		if (!strpos($f, $cfgSettingUpdated)) {
			if (strpos($f, $cfgSettingComment)) {
				$f = str_replace($cfg, $f); 
			}
		}
	}
	$upon_load = function($settings) {
		global $custom_settings;
		echo $custom_settings['social']['tab']['label'];
	};
	$upon_save = function($settings) { 
		global $LANG;
		echo $LANG;
		$f = file_get_contents(GSROOTPATH . 'gsconfig.php');
		if ($settings['main']['my_second_setting']['value']) {
			$debug = str_replace('define(\'GSDEBUG\', TRUE)', 'define(\'GSDEBUG\', FALSE)', $f);
			file_put_contents(GSROOTPATH . 'gsconfig.php', $debug);
		}  else {
			$debug = str_replace('define(\'GSDEBUG\', FALSE)', 'define(\'GSDEBUG\', TRUE)', $f);
			file_put_contents(GSROOTPATH . 'gsconfig.php', $debug);
		}
	};
?>